#include "shape.h"
string Shape::getName() const
{
    return _name;
}