#ifndef SVG_CIRCLE
#define SVG_CIRCLE
#include "svg_shape.h"

class SvgCircle : public SvgShape {
public:
    SvgCircle(double x, double y, double r):_x(x),_y(y),_r(r){
    }
    std::string toSVG() const { 

        std::string s="<circle cx=\"" + std::to_string(_x) + "\" cy=\"" + std::to_string(_y) + "\" r=\"" + std::to_string(_r)
    + "\" stroke-width=\"" + std::to_string(getstrokeWidth()) + "\" stroke=\"" + getStrokeColor()+"\" fill=\""+ getFillColor() +"\"/>";
        return s;
    }
private:
    double _x, _y, _r;
};
#endif