#ifndef SVG_POLYGON
#define SVG_POLYGON
#include "svg_shape.h"
#include <string>
class SvgPolygon : public SvgShape {
public:
    SvgPolygon(std::vector<double *> const & v): _v(v){
        setStroke(0,"black");
        setFillColor("black");
    }
    std::string toSVG() const {
        std::string p = "";
        for (int i = 0; i < _v.size(); i++)
        {
            p += std::to_string(_v[i][0]);
            p += " ";
            p += std::to_string(_v[i][1]);
            if (i != _v.size() - 1)
            {
                p += " ";
            }
        }
        std::string s = "<polygon points=\"" + p + "\" stroke-width=\"" + std::to_string(getstrokeWidth()) + "\" stroke=\"" + getStrokeColor() + "\" fill=\"" + getFillColor() + "\"/>";
        return s;
    }
private:
    std::vector<double *> _v;
};
#endif