#ifndef SVG_LINE
#define SVG_LINE
#include "svg_shape.h"
class SvgLine : public SvgShape {
public:
    SvgLine(double x1, double y1, double x2, double y2): _x1(x1), _y1(y1), _x2(x2), _y2(y2){
    }
    std::string toSVG() const {
        std::string s="<line x1=\"" + std::to_string(_x1) + "\" y1=\"" + std::to_string(_y1)
    + "\" x2=\"" + std::to_string(_x2) + "\" y2=\"" + std::to_string(_y2)
    + "\" stroke-width=\"" + std::to_string(getstrokeWidth()) + "\" stroke=\"" + getStrokeColor() + "\" fill=\"" + getFillColor() + "\"/>";
        return s;
    }
private:
    double _x1, _y1, _x2, _y2;
};
#endif